# Iteration 0 run

Status: **success**. Data: **Yambda real data**.

Task: rank the recorded listen item among 21 candidates using strictly earlier recorded interactions.
Training precedes development globally; the later test interval is reserved and not scored.

Pipeline wall time (excluding uv setup and handoff): 162.659 s.
Process peak RSS: 601.2 MiB; see environment.json for limitations.

Training queries: 3000; development queries: 1000.

| Method | NDCG@10 | Recall@10 | Users |
|---|---:|---:|---:|
| popularity | 0.608240 | 0.905000 | 72 |
| boosting | 0.864996 | 0.962000 | 72 |

Checks: preflight suite status in checks.json; sampled-history brute-force feature check passed.
Exclusions, target coverage, timestamp ties, repeat rates, and history completeness are in audit.json and source_and_extraction.json.

Next decision: Pending review of the returned real-data bundle; no automatic method search authorized.

Limitations:

- Event-conditioned ranking with 20 uniform sampled alternatives; not CTR, full-catalog ranking, exposure correction, or verified negative preference.
- Logged timestamps are treated as event-identity availability times. Ingestion/availability timestamps are absent; live serving and start-of-play validity are unverified. Playback outcomes are not predictors.
- Dataset user selection itself uses future activity; within-release user sampling cannot remove that source selection bias.
- Item popularity is measured only within sampled users. All recorded event types count as interactions, including negative feedback actions.
- Historical records update through development strictly before each query; model weights and item universe remain frozen at training boundary.
- Histories are left-censored by the released observation interval. Uniform alternatives are often easier than production retrieval candidates.
- Fixed modest classifier is a warmup baseline, not the final strong manual-feature baseline. No search implemented; no test-set scoring.
- Synthetic checks establish implementation behavior, not recommendation quality or Mac compatibility.
