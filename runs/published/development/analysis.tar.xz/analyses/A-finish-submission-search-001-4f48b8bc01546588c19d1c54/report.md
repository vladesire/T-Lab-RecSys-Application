# Analysis A-finish-submission-search-001

Engine: ranking. Phases: development.
Metric cells: 288. Comparisons: 72.

## Selected inputs

- R-finish-search-isolated-001 (development, fresh_execution): Pilot-informed development evidence; within-protocol fixed comparisons; fingerprint 0f192967e1357d509ee3b3450021e8c74d9ab3ad6fd32c9165e4b5f97f8d7c60

## Checks

- P20_all: passed: Ranking descriptors and arrays agree
- P20_decay: passed: Ranking descriptors and arrays agree
- P20_decay_popularity: passed: Ranking descriptors and arrays agree
- P20_forward: passed: Ranking descriptors and arrays agree
- P20_manual: passed: Ranking descriptors and arrays agree
- P20_no_pair: passed: Ranking descriptors and arrays agree
- P20_original: passed: Ranking descriptors and arrays agree
- P20_personal_frequency: passed: Ranking descriptors and arrays agree
- P20_popularity: passed: Ranking descriptors and arrays agree
- P20_random: passed: Ranking descriptors and arrays agree
- P20_random_search: passed: Ranking descriptors and arrays agree
- P20_recency_rule: passed: Ranking descriptors and arrays agree
- U20_all: passed: Ranking descriptors and arrays agree
- U20_decay: passed: Ranking descriptors and arrays agree
- U20_decay_popularity: passed: Ranking descriptors and arrays agree
- U20_forward_frozen: passed: Ranking descriptors and arrays agree
- U20_manual: passed: Ranking descriptors and arrays agree
- U20_no_pair: passed: Ranking descriptors and arrays agree
- U20_original: passed: Ranking descriptors and arrays agree
- U20_personal_frequency: passed: Ranking descriptors and arrays agree
- U20_popularity: passed: Ranking descriptors and arrays agree
- U20_random: passed: Ranking descriptors and arrays agree
- U20_random_search_frozen: passed: Ranking descriptors and arrays agree
- U20_recency_rule: passed: Ranking descriptors and arrays agree
- R-finish-search-isolated-001:upstream-anchor: unverified: Anchor reproduction is required in iteration1, not rerun by overnight

## Limitations

- Runs, reproductions, estimator seeds and populations are not pooled.
- Bundle integrity does not establish temporal validity or historical tie-key independence.
- R-finish-search-isolated-001: Synthetic executions establish adapter behavior only; actual Mac anchor acceptance remains required.
- R-finish-search-isolated-001: Sampled candidates and reused development data are not a pristine final test.
- R-finish-search-isolated-001: Full feature dictionary is computed upstream; selected column count does not measure feature computation savings.
- R-finish-search-isolated-001: Upstream metrics use integer item fallback; port uses lexical IDs if a 64-bit tie-key collision occurs.
